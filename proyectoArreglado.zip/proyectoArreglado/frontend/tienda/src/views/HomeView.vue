<script setup>
</script>

<template>
  <main>
    <h1>Es el home</h1>
  </main>
</template>
